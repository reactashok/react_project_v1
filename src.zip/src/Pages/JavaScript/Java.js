function greetUser(){
    let name = "anbu";
    let msg = "Hello" + name + "i am learning JavaScript !";
    console.log(msg)
};
greetUser()